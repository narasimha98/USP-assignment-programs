/* C program to illustrste exec() function */
#include<stdio.h>
#include<stdlib.h>
#include <sys/wait.h>
char *env_init[] = { "USER=unknown", "PATH=/tmp", NULL };
int main(void)
{
pid_t pid;
if ((pid = fork()) < 0) 
{
printf("fork error");
} 
else if (pid == 0) 
{ 
/* specify pathname, specify environment */
if (execle("/home/sar/bin/echoall", "echoall", "myarg1",
"MY ARG2", (char *)0, env_init) < 0)
printf("execle error");
}
if (waitpid(pid, NULL, 0) < 0)
printf("wait error");
if ((pid = fork()) < 0) 
{
printf("fork error");
} 
else if (pid == 0) 
{ 
/* specify filename, inherit environment */
if (execlp("echoall", "echoall", "only 1 arg", (char *)0) < 0)
printf("execlp error");
}
exit(0);
}

/* OUTPUT:

./a.out

argv[0]:echoall
argv[1]:myarg1
argv[2]:MY ARG2
USER:unknown
PATH=/tmp
$ argv[0]:echoall
argv[1]:only 1 arg
USER=sar
LOGNAME=sar
SHELL=/bin/bash
HOME=/home/sar
*/


