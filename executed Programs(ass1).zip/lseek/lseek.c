// C program for copying contents of one file in reverse order in another file and displaying number of bytes using lseek() system call.

#include<sys/types.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
char buffer[1];
int main()
{
  int fd1,fd2;
  char file1[50],file2[50];
  printf("Enter the file to reverse:\n");
  gets(file1);
  if((fd1=open("file1.txt",O_RDONLY))==-1)
{
  printf("File does not exist\n");
  return -1;
}
printf("Enter file to output in:\n");
gets(file2);
fd2=open("file2.txt",O_RDWR|O_CREAT);
int size=lseek(fd1,0,SEEK_END);
printf("The number of bytes read in file2 is: %d\n",size);
int i;
for(i=1;i<=size;i++)
{
if((lseek(fd1,-i,SEEK_END))==-1)
{
 printf("%s",strerror(errno));
}
int rd=read(fd1,buffer,1);
int wr=write(fd2,buffer,1);
if(wr==0)
{
 printf("Did not write to file\n");
 return -1;
}
}
return 0;
}

/*OUTPUT:

Enter the file to reverse:
file1.txt
Enter the file to output in:
file2.txt
The number of bytes read in file2 is:
7 (including space)
*/

/*when u open file2.txt, the contents will be in reverse order.
*/



