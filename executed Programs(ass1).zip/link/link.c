// C program to demonstrate ln command using link system call

#include<stdio.h>
#include<unistd.h>
int main(int argc,char *argv[])
{
if(argc!=3)
{
  printf("usage: %s <src_file><dest_file>\n",argv[0]);
  return 0;
}
if(link(argv[1],argv[2])==-1)
{
  printf("link error\n");
  return 1;
}
printf("Files Linked\n");
printf("Inode number of linked files\n");
char str[100];
sprintf(str,"ls -i %s %s\n",argv[1],argv[2]);
system(str);
return 0;
}

/*EXECUTION:

gcc link.c
./a.out link1.txt link2.txt
*/

/*OUTPUT:

Files linked
Inode number of linked files
799270 link1.txt 799270 link2.txt
*/
  
